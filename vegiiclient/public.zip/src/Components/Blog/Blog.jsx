import React from 'react'
import Header from '../Navbar/Navbar'
import Footer from '../Footer/Footer'
import './Blog.css'
import Breadcome from '../Common/Breadcome'
import Blogcommon from './Blogcommon'
import img1 from '../../Assets/image_1.jpg'
import img2 from '../../Assets/image_2.jpg'
import img3 from '../../Assets/image_3.jpg'
import img4 from '../../Assets/image_4.jpg'
import img5 from '../../Assets/image_5.jpg'
import img6 from '../../Assets/image_6.jpg'
const Blog = () => {
  return (
    <div>
      <Header/>
      <Breadcome breadpage={"Blog"} breadtitle={"blog"}/>
      <div className='blog'>
        <div className='blog-left' >
          <Blogcommon image={<img src={img1} alt='not Found' />} small={"July 20, 2019 Admin  3"} h2={"Even the all-powerful Pointing has no control about the blind texts"} p={"Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts."} />

          <Blogcommon image={<img src={img2} alt='not Found' />} small={"July 20, 2019 Admin  3"} h2={"Even the all-powerful Pointing has no control about the blind texts"} p={"Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts."} />

          <Blogcommon image={<img src={img3} alt='not Found' />} small={"July 20, 2019 Admin  3"} h2={"Even the all-powerful Pointing has no control about the blind texts"} p={"Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts."} />

          <Blogcommon image={<img src={img4} alt='not Found' />} small={"July 20, 2019 Admin  3"} h2={"Even the all-powerful Pointing has no control about the blind texts"} p={"Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts."} />

          <Blogcommon image={<img src={img5} alt='not Found' />} small={"July 20, 2019 Admin  3"} h2={"Even the all-powerful Pointing has no control about the blind texts"} p={"Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts."} />

          <Blogcommon image={<img src={img6} alt='not Found' />} small={"July 20, 2019 Admin  3"} h2={"Even the all-powerful Pointing has no control about the blind texts"} p={"Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts."} />

        </div>
        <div className='blog-right'>
          <div className='blog-input'>
            <input type="text" placeholder='Search...' />
          </div>
          <br /><br /><br />

            <div className='catagery'>
              <h2> Categories </h2>
              <div className='blog-catagery'>
                <p>Vegetables</p>
                <p>(12)</p>
                
              </div>
              <hr />
              <div className='blog-catagery'>
                <p>Friuts</p>
                <p>(22)</p>
              </div>
              <hr />
              <div className='blog-catagery'>
                <p>Juices</p>
                <p>(18)</p>
              </div>
              <hr />
              <div className='blog-catagery'>
                <p>Dries</p>
                <p>(23)</p>
              </div>
              <hr />
            </div>
        </div>
      </div>
      <Footer/>
      </div>
  )
}

export default Blog