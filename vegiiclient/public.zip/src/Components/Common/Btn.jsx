import React from 'react'
import './Common.css'
const Btn = ({btn}) => {
  return (
    <div>
        <button type='submit' className='btn'>{btn}</button>
    </div>
  )
}

export default Btn